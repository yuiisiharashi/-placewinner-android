PlaceWinner Android wrapper scaffold

This is a STARTER PROJECT, not a verified production APK. It contains the uploaded web assets and a native Android WebView wrapper with Unity Ads SDK initialization using the Unity Game ID and placement IDs supplied by the user. Test mode is enabled.

IMPORTANT:
1. The original web app uses Firebase Web signInWithPopup. Google sign-in may not work inside Android WebView; this needs testing and may require native Google sign-in / OAuth redirect handling. Do not assume login is fixed.
2. Existing web buttons are still demo buttons until app.js is wired to PlaceWinnerAds.showRewarded() and the onUnityRewarded callback. No points are awarded by this scaffold yet. Only grant points after callback true and implement server-side anti-fraud before real cash rewards.
3. Build with Android Gradle Plugin 8.7.3 / Gradle 8.9+ / JDK 17, Android SDK 35. Unity dependency availability/version may need checking in build environment.
4. Unity test mode is ON. Do not publish or use real reward balances until end-to-end testing is complete.

Build APK in Android Studio: Open this folder as a project, sync Gradle, then Build > Build APK(s).

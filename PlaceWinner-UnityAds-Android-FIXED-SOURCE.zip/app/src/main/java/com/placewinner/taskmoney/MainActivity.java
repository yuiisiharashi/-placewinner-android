package com.placewinner.taskmoney;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;

public class MainActivity extends Activity {
    // IDs recovered from the saved PlaceWinner Unity Ads project in the Library.
    private static final String GAME_ID = "800394219";
    private static final String REWARDED = "BP_Rewarded_Android";
    private static final String INTERSTITIAL = "BP_Interstitial_Android";
    // Live mode. Switch to true only when deliberately testing with Unity test ads.
    private static final boolean TEST_MODE = false;

    private WebView webView;
    private volatile boolean initialized = false;
    private volatile boolean rewardedReady = false;
    private volatile boolean rewardedInProgress = false;
    private volatile boolean interstitialReady = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new UnityAdsBridge(), "UnityAdsBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        UnityAds.initialize(getApplicationContext(), GAME_ID, TEST_MODE, new IUnityAdsInitializationListener() {
            @Override public void onInitializationComplete() {
                initialized = true;
                loadRewarded();
                loadInterstitial();
            }
            @Override public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                initialized = false;
                runJs("window.onUnityAdError && window.onUnityAdError('Unity Ads initialization failed');");
            }
        });
    }

    private void runJs(String js) {
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private void loadRewarded() {
        if (!initialized) return;
        UnityAds.load(REWARDED, new IUnityAdsLoadListener() {
            @Override public void onUnityAdsAdLoaded(String placementId) { rewardedReady = true; }
            @Override public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
                rewardedReady = false;
                runJs("window.onUnityAdError && window.onUnityAdError('Rewarded ad unavailable; try again later');");
            }
        });
    }

    private void loadInterstitial() {
        if (!initialized) return;
        UnityAds.load(INTERSTITIAL, new IUnityAdsLoadListener() {
            @Override public void onUnityAdsAdLoaded(String placementId) { interstitialReady = true; }
            @Override public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) { interstitialReady = false; }
        });
    }

    public class UnityAdsBridge {
        @JavascriptInterface public void showRewardedAd() {
            runOnUiThread(() -> {
                if (!initialized) { notifyAdError("Unity Ads belum siap."); return; }
                if (rewardedInProgress) return;
                if (!rewardedReady) {
                    Toast.makeText(MainActivity.this, "Iklan belum siap, coba lagi sebentar.", Toast.LENGTH_SHORT).show();
                    loadRewarded();
                    notifyAdError("Iklan belum tersedia. Coba lagi sebentar.");
                    return;
                }
                rewardedReady = false;
                rewardedInProgress = true;
                UnityAds.show(MainActivity.this, REWARDED, new IUnityAdsShowListener() {
                    @Override public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
                        rewardedInProgress = false;
                        runJs("window.onUnityRewardedAdCompleted && window.onUnityRewardedAdCompleted(false);");
                        loadRewarded();
                    }
                    @Override public void onUnityAdsShowStart(String placementId) {}
                    @Override public void onUnityAdsShowClick(String placementId) {}
                    @Override public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
                        rewardedInProgress = false;
                        boolean completed = state == UnityAds.UnityAdsShowCompletionState.COMPLETED;
                        runJs("window.onUnityRewardedAdCompleted && window.onUnityRewardedAdCompleted(" + completed + ");");
                        loadRewarded();
                    }
                });
            });
        }

        // Secondary saved placement. It is exposed for a deliberate app UI trigger;
        // it is not forced over the user's screen automatically.
        @JavascriptInterface public void showInterstitialAd() {
            runOnUiThread(() -> {
                if (!initialized || !interstitialReady) { loadInterstitial(); return; }
                interstitialReady = false;
                UnityAds.show(MainActivity.this, INTERSTITIAL, new IUnityAdsShowListener() {
                    @Override public void onUnityAdsShowFailure(String p, UnityAds.UnityAdsShowError e, String m) { loadInterstitial(); }
                    @Override public void onUnityAdsShowStart(String p) {}
                    @Override public void onUnityAdsShowClick(String p) {}
                    @Override public void onUnityAdsShowComplete(String p, UnityAds.UnityAdsShowCompletionState s) { loadInterstitial(); }
                });
            });
        }
    }

    private void notifyAdError(String message) {
        String safe = message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
        runJs("window.onUnityAdError && window.onUnityAdError('" + safe + "');");
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("UnityAdsBridge"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}

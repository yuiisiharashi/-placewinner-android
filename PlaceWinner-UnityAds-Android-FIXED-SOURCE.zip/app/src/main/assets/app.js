const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const POINTS_PER_USD=5000;
const DEMO_AD_REWARD=50, DAILY_AD_LIMIT=10, MIN_WITHDRAW=25000;
const I18N={
id:{home:"Home",tasks:"Tasks",spin:"Spin",offerwall:"Offerwall",profile:"Profile",welcome:"Selamat datang",welcomeSub:"Selesaikan tugas, kumpulkan poin, dan kelola reward kamu."},
en:{home:"Home",tasks:"Tasks",spin:"Spin",offerwall:"Offerwall",profile:"Profile",welcome:"Welcome",welcomeSub:"Complete tasks, collect points, and manage your rewards."}
};
let state=JSON.parse(localStorage.getItem("pw_state_v4")||"null")||{
user:{id:"PW-10001",username:"Yuda",email:"demo@placewinner.app",created:"2026-10-08",language:"id"},
points:12500,today:850,total:18500,completed:6,pending:2,route:"home",loggedIn:false,
ads:{count:0,date:new Date().toISOString().slice(0,10)},spinUsed:false,spinCount:0,spinAdReady:false,spinAdBusy:false,
tasks:[],offers:[],transactions:[],notifications:[
{id:1,title:"Reward received",text:"Demo reward berhasil ditambahkan.",unread:true,date:"Hari ini"},
{id:2,title:"Welcome",text:"Selamat datang di placeWinner-taskmoney.",unread:true,date:"Hari ini"}],
settings:{dark:true,notifications:true,currency:"USD"},paymentMethods:[]
};
const taskSeed=[
["Watch a short video","Tonton video pendek dan submit bukti selesai.","YouTube Watch",500,"2 min"],
["Visit partner website","Kunjungi halaman partner selama waktu yang ditentukan.","Website Visit",350,"2 min"],
["Follow social account","Follow akun sosial yang tercantum pada instruksi.","Social Media",300,"1 min"],
["Subscribe channel","Subscribe channel demo dan kirim screenshot.","Subscribe",450,"2 min"],
["Complete mini survey","Jawab survei singkat dengan data yang jujur.","Survey",700,"4 min"],
["Test an app screen","Coba alur demo aplikasi dan laporkan hasilnya.","App Testing",1000,"6 min"],
["Simple registration","Selesaikan pendaftaran pada situs demo.","Registration",800,"5 min"],
["Data entry","Masukkan data sederhana sesuai instruksi.","Data Entry",600,"4 min"]
];
const offerSeed=[
["Install & open partner app","Install aplikasi partner dan buka sampai selesai.","1200","5 min"],
["Try a free game level","Mainkan level awal game partner.","1800","8 min"],
["Complete a short survey","Survei partner dengan beberapa pertanyaan.","1500","6 min"],
["Create a free account","Buat akun pada layanan partner.","1000","4 min"]
];
if(!state.tasks.length) state.tasks=taskSeed.map((x,i)=>({id:"T"+(i+1),title:x[0],desc:x[1],cat:x[2],reward:x[3],time:x[4],status:"Available"}));
if(!state.offers.length) state.offers=offerSeed.map((x,i)=>({id:"O"+(i+1),title:x[0],desc:x[1],reward:+x[2],time:x[3],status:"Available"}));
function save(){localStorage.setItem("pw_state_v4",JSON.stringify(state))}
function usd(p){return "$"+(p/POINTS_PER_USD).toFixed(2)}
function toast(t){let e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2300)}
function addTx(type,points,status="Completed",desc=""){state.transactions.unshift({id:"TX-"+Date.now(),type,date:new Date().toLocaleString(),points,status,desc});}
function addNotif(title,text){state.notifications.unshift({id:Date.now(),title,text,unread:true,date:"Baru"})}
function setRoute(r){state.route=r;save();render()}
function render(){
 if(!state.loggedIn){$("#main").classList.add("hidden");$("#auth").classList.remove("hidden");renderAuth();return}
 $("#auth").classList.add("hidden");$("#main").classList.remove("hidden");
 $("#drawerName").textContent=state.user.username;$("#drawerId").textContent=state.user.id;
 $$(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.route===state.route));
 let c=$("#content"); c.innerHTML=window.routes[state.route]?window.routes[state.route]():window.routes.home();
 bind();
 applyLang();
}
function renderAuth(){
 const form=document.querySelector("#authForm");
 form.innerHTML=`<div class="card" style="margin-top:18px;text-align:center"><h2>Masuk dengan Google</h2><p class="muted">Gunakan akun Google untuk masuk ke placeWinner.</p><button type="button" class="btn full" id="googleLogin">🔵 Lanjutkan dengan Google</button><p class="muted" style="font-size:12px;margin-top:12px">Login memerlukan koneksi internet.</p></div>`;
 const btn=document.querySelector("#googleLogin");
 btn.addEventListener("click",async()=>{
   if(btn.disabled) return;
   btn.disabled=true; btn.textContent="Membuka login Google…";
   try{
     if(!window.FirebaseBackend?.googleLogin) throw new Error("Firebase belum selesai dimuat. Periksa koneksi internet lalu coba lagi.");
     await window.FirebaseBackend.googleLogin();
   }catch(e){
     toast(authError(e));
   }finally{
     btn.disabled=false; btn.textContent="🔵 Lanjutkan dengan Google";
   }
 });
}
function authError(e){
 const code=e?.code||"";
 const map={
  "auth/popup-closed-by-user":"Login Google dibatalkan.",
  "auth/popup-blocked":"WebView memblokir jendela login. APK perlu integrasi Google Sign-In native dari AppMint.",
  "auth/unauthorized-domain":"Domain asal login belum diizinkan di Firebase.",
  "auth/network-request-failed":"Koneksi internet bermasalah.",
  "auth/operation-not-allowed":"Aktifkan penyedia Google di Firebase Authentication.",
  "auth/operation-not-supported-in-this-environment":"Login Google berbasis web tidak didukung di lingkungan APK ini. Perlu integrasi Google Sign-In native."
 };
 return map[code]||("Login Google gagal: "+(e?.message||code||"unknown error"));
}
function applyFirebaseUser(user){
 if(!user){state.loggedIn=false;save();render();return;}
 state.loggedIn=true;
 state.user.id="PW-"+user.uid.slice(0,8).toUpperCase();
 state.user.username=user.displayName||user.email?.split("@")[0]||"User";
 state.user.email=user.email||"";
 save(); render();
}
let firebaseAuthListenerAttached=false;
function attachFirebaseAuthListener(){
 if(firebaseAuthListenerAttached || !window.FirebaseBackend?.onAuthStateChanged) return;
 firebaseAuthListenerAttached=true;
 window.FirebaseBackend.onAuthStateChanged(window.FirebaseBackend.auth,applyFirebaseUser);
}
attachFirebaseAuthListener();
window.addEventListener("firebase-backend-ready",attachFirebaseAuthListener);
function moneyCard(){return `<div class="balance"><div class="label">POINTS BALANCE</div><div class="points">${state.points.toLocaleString()} pts</div><div class="usd">${usd(state.points)} USD available</div><div class="row" style="margin-top:14px"><button class="btn gold" data-route="withdraw">Withdraw</button><button class="btn ghost" data-route="wallet">Wallet</button></div></div>`}
const routes={
home:()=>`<div class="greeting"><div><p class="muted" style="margin:0">Welcome back,</p><h2>${state.user.username} 👋</h2></div><div class="avatar">${state.user.username[0]?.toUpperCase()||"U"}</div></div>${moneyCard()}
<div class="grid"><div class="stat"><small>Today's Earnings</small><b>${state.today.toLocaleString()}</b></div><div class="stat"><small>Total Earnings</small><b>${state.total.toLocaleString()}</b></div><div class="stat"><small>Completed Tasks</small><b>${state.completed}</b></div><div class="stat"><small>Pending Rewards</small><b>${state.pending}</b></div></div>
<div class="actions"><button class="action" data-route="ads">📺<strong>Watch Ad & Earn</strong><span>+50 pts · ${Math.max(0,DAILY_AD_LIMIT-state.ads.count)} left</span></button><button class="action" data-route="tasks">📋<strong>Complete Tasks</strong><span>Earn from microtasks</span></button><button class="action" data-route="spin">🎰<strong>Lucky Spin</strong><span>Daily reward</span></button><button class="action" data-route="offerwall">🎁<strong>Offerwall</strong><span>Partner offers</span></button></div>
<div class="ad-banner"><div>AD SPACE<br><b>Banner advertisement — TEST/DEMO</b></div></div>
<div class="section-head"><h3>Recent Transactions</h3><button data-route="transactions">View all</button></div>${txList(3)}`,
tasks:()=>`<div class="section-head"><h2 style="margin:0">Tasks</h2><span class="badge">8 demo tasks</span></div><p class="muted">Selesaikan tugas dan kirim bukti. Reward hanya masuk setelah approval.</p>${state.tasks.map(t=>`<div class="card task-card"><div class="task-top"><div><b>${t.title}</b><p class="muted">${t.desc}</p></div><span class="reward">+${t.reward}</span></div><div class="meta"><span class="badge">${t.cat}</span><span class="badge gold">${t.time}</span><span class="badge ${t.status==="Approved"?"green":t.status==="Rejected"?"red":""}">${t.status}</span></div><button class="btn full ${t.status==="Approved"?"ghost":""}" data-task="${t.id}">${t.status==="Available"?"Start":t.status==="Approved"?"View result":"Open task"}</button></div>`).join("")}`,
taskDetails:(id)=>{let t=state.tasks.find(x=>x.id===id);return `<button class="btn ghost" data-route="tasks">← Back</button><div class="card" style="margin-top:12px"><span class="badge">${t.cat}</span><h1 class="detail-title">${t.title}</h1><div class="reward">+${t.reward} points · ${usd(t.reward)}</div><p class="muted">${t.desc}</p><div class="section-head"><h3>Requirements</h3></div><ul class="checklist"><li>Ikuti instruksi task dengan benar.</li><li>Sediakan bukti yang diminta.</li><li>Jangan submit bukti palsu atau duplikat.</li><li>Reward masuk setelah review.</li></ul><div class="section-head"><h3>Instructions</h3></div><p class="muted">Kerjakan task sesuai deskripsi, lalu tekan Submit Proof untuk mengirim bukti demo.</p><button class="btn full" data-start="${t.id}">${t.status==="Started"?"Submit Proof":"Start Task"}</button></div>`},
submit:(id)=>{let t=state.tasks.find(x=>x.id===id);return `<button class="btn ghost" data-taskdetail="${id}">← Back</button><div class="card" style="margin-top:12px"><h2>Submit Proof</h2><p class="muted">${t.title} · +${t.reward} points</p><label>Proof image / screenshot</label><input type="file" accept="image/*"><label>Text proof</label><textarea id="proofText" rows="4" placeholder="Tulis bukti atau hasil pengerjaan..."></textarea><label>URL</label><input id="proofUrl" placeholder="https://example.com"><label>Username</label><input id="proofUser" placeholder="Username jika diperlukan"><label>Notes</label><textarea id="proofNotes" rows="3"></textarea><button class="btn green full" data-submit="${id}">Submit Proof</button></div>`},
spin:()=>`<div class="spin-wrap">
<h2>Lucky Spin</h2><div class="spin-hero">
  <div class="spin-spark spark1">✦</div><div class="spin-spark spark2">✧</div>
  <div class="spin-spark spark3">✦</div><div class="spin-spark spark4">✧</div>
  <div class="spin-crown">♛</div>
  <div class="spin-title">LUCKY <span>SPIN</span></div>
  <div class="spin-subtitle">Putar keberuntunganmu hari ini</div>
  <div class="spin-wheel-shell">
    <div class="spin-wheel">
      <div class="spin-segment s1">ZONK</div>
      <div class="spin-segment s2">10</div>
      <div class="spin-segment s3">25</div>
      <div class="spin-segment s4">50</div>
      <div class="spin-segment s5">100</div>
      <div class="spin-segment s6">10</div>
      <div class="spin-center">★</div>
    </div>
    <div class="spin-pointer">▼</div>
  </div>
  <div class="spin-prizes">
    <span>💰 10</span><span>🎁 25</span><span>⭐ 50</span><span>💎 100</span><span>😵 ZONK</span>
  </div>
  <button class="spin-main-btn" id="pretty-spin-btn">🎰 SPIN SEKARANG</button>
  <div class="spin-ad-note">📺 Selesaikan 1 iklan untuk 1 spin</div>
</div>
<p class="muted"><b>1 SPIN = 1 IKLAN WAJIB.</b> Selesaikan 1 iklan terlebih dahulu sebelum tombol SPIN aktif.</p><div class="wheel" id="wheel"><div class="wheel-inner">SPIN</div></div><div style="font-size:30px;font-weight:900;margin:4px 0">${state.spinCount||0} / 200</div>
<div class="progress" style="margin-top:9px"><i style="width:${Math.min(100,((state.spinCount||0)%200)/2)}%"></i></div>
<p style="margin:10px 0 0;font-weight:800">Tersisa ${Math.max(0,200-(state.spinCount||0))} spin lagi</p>
</div><div class="card" style="margin-top:11px"><div class="row between"><span>1. Watch ad</span><span class="badge ${state.spinAdReady?'green':''}">${state.spinAdReady?'DONE':'REQUIRED'}</span></div><button class="btn full" id="spinAdBtn" ${state.spinAdBusy||state.spinAdReady?'disabled':''} style="margin-top:10px">${state.spinAdBusy?'Watching ad...':state.spinAdReady?'Ad completed ✓':'Watch 1 Ad'}</button><button class="btn gold full" id="spinBtn" ${state.spinAdReady?'':'disabled'} style="margin-top:10px">${state.spinAdReady?'2. SPIN NOW':'2. Spin after ad'}</button></div><div class="card" style="margin-top:11px"><b>Possible rewards</b><div class="meta" style="justify-content:center;margin-top:10px"><span class="badge">ZONK</span><span class="badge">+10</span><span class="badge">+25</span><span class="badge gold">+50</span><span class="badge gold">+100</span></div><p class="muted" style="margin-bottom:0">+50 dan +100 dibuat sangat jarang. Setiap spin wajib menyelesaikan 1 iklan terlebih dahulu.</p></div></div>`,
ads:()=>`<button class="btn ghost" data-route="home">← Back</button><div class="card" style="margin-top:12px;text-align:center"><h2>Watch Ad & Earn</h2><div style="font-size:42px;margin:15px">📺</div><h1 style="color:var(--gold)">+50 Points</h1><p class="muted">Tonton iklan Unity sampai selesai untuk menerima 50 poin.</p><div class="grid"><div class="stat"><small>Today's Ads</small><b>${state.ads.count} / ${DAILY_AD_LIMIT}</b></div><div class="stat"><small>Remaining</small><b>${Math.max(0,DAILY_AD_LIMIT-state.ads.count)}</b></div></div><div class="ad-banner">Unity Ads Rewarded Video<br><b>Menunggu koneksi SDK native</b></div><button class="btn green full" id="watchAd" ${state.ads.count>=DAILY_AD_LIMIT?"disabled":""}>Watch Advertisement</button><p class="muted" style="margin-top:12px">Reward is granted only after a valid SDK completion callback in production.</p></div>`,
offerwall:()=>`<div class="section-head"><h2 style="margin:0">Offerwall</h2><span class="badge">DEMO</span></div><p class="muted">Reward hanya dikreditkan setelah provider mengirim callback/postback yang valid.</p><div class="ad-banner">Offerwall placement</div>${state.offers.map(o=>`<div class="card offer-card"><div class="task-top"><div><b>${o.title}</b><p class="muted">${o.desc}</p></div><span class="reward">+${o.reward}</span></div><div class="meta"><span class="badge">${o.time}</span><span class="badge">${o.status}</span></div><button class="btn full" data-offer="${o.id}">${o.status==="Available"?"Start Offer":"View status"}</button></div>`).join("")}`,
offerDetails:(id)=>{let o=state.offers.find(x=>x.id===id);return `<button class="btn ghost" data-route="offerwall">← Back</button><div class="card" style="margin-top:12px"><span class="badge">Offerwall</span><h1 class="detail-title">${o.title}</h1><div class="reward">+${o.reward} points</div><p class="muted">${o.desc}</p><div class="section-head"><h3>Requirements</h3></div><ul class="checklist"><li>Complete the partner offer exactly as described.</li><li>Use the same user identifier when required.</li><li>Do not use duplicate accounts.</li></ul><button class="btn full" id="startOffer" data-id="${id}">${o.status==="Available"?"Start Offer":"Status: "+o.status}</button><p class="muted">Prototype: clicking Start changes status only; no points are awarded without provider callback.</p></div>`},
wallet:()=>`<div class="section-head"><h2 style="margin:0">Wallet</h2></div>${moneyCard()}<div class="grid"><div class="stat"><small>Pending withdrawal</small><b>${state.pending.toLocaleString()}</b></div><div class="stat"><small>Total withdrawn</small><b>0 pts</b></div></div><div class="actions"><button class="action" data-route="transactions">📜<strong>Transactions</strong><span>See all activity</span></button><button class="action" data-route="withdraw">💸<strong>Withdraw</strong><span>Minimum 25,000 pts</span></button></div>`,
withdraw:()=>`<button class="btn ghost" data-route="wallet">← Back</button><div class="card" style="margin-top:12px"><h2>Withdraw</h2><p class="muted">Minimum withdrawal: 25,000 points = $5.00</p><div class="balance"><small>Available</small><h2>${state.points.toLocaleString()} pts · ${usd(state.points)}</h2></div><label>Amount (points)</label><input id="withdrawAmount" type="number" min="${MIN_WITHDRAW}" step="1000" placeholder="25000"><label>Payment method</label><select id="withdrawMethod"><option>DANA</option><option>OVO</option><option>GoPay</option><option>Bank Transfer</option><option>PayPal</option><option>USDT/Crypto</option></select><label>Payment details</label><input id="paymentDetails" placeholder="Nomor / rekening / wallet address"><button class="btn gold full" id="withdrawBtn">Request Withdrawal</button><p class="muted">Prototype mode: request is recorded as Pending. It is not a real payment.</p></div>`,
transactions:()=>`<div class="section-head"><h2 style="margin:0">Transactions</h2><select id="txFilter" style="width:auto"><option>All</option><option>Reward</option><option>Withdrawal</option></select></div><div class="card">${txList(100)}</div>`,
notifications:()=>`<div class="section-head"><h2 style="margin:0">Notifications</h2><button id="readAll">Mark all read</button></div><div class="card">${state.notifications.length?state.notifications.map(n=>`<div class="tx"><div><b>${n.title}</b><div class="muted">${n.text}</div><small>${n.date}</small></div>${n.unread?'<span class="badge">NEW</span>':''}</div>`).join(""):'<div class="empty">No notifications</div>'}</div>`,
profile:()=>`<div class="card" style="text-align:center"><div class="avatar" style="margin:auto;width:68px;height:68px;font-size:24px">${state.user.username[0]?.toUpperCase()||"U"}</div><h2>${state.user.username}</h2><p class="muted">${state.user.email}<br>${state.user.id}</p><div class="grid"><div class="stat"><small>Points</small><b>${state.points.toLocaleString()}</b></div><div class="stat"><small>USD</small><b>${usd(state.points)}</b></div></div></div><div class="actions"><button class="action" data-route="wallet">💰<strong>Wallet</strong></button><button class="action" data-route="withdraw">💸<strong>Withdraw</strong></button><button class="action" data-route="transactions">📜<strong>Transactions</strong></button><button class="action" data-route="settings">⚙️<strong>Settings</strong></button></div>`,
settings:()=>`<button class="btn ghost" data-route="profile">← Back</button><div class="section-head"><h2 style="margin:0">Settings</h2></div><div class="card"><div class="tx"><div><b>Language</b><div class="muted">Bahasa Indonesia / English</div></div><select id="language" style="width:150px"><option value="id" ${state.user.language==="id"?"selected":""}>Indonesia</option><option value="en" ${state.user.language==="en"?"selected":""}>English</option></select></div><div class="tx"><div><b>Currency</b><div class="muted">Default application currency</div></div><select id="currency" style="width:120px"><option selected>USD</option></select></div><div class="tx"><div><b>Dark Mode</b><div class="muted">Premium dark interface</div></div><button class="switch on" id="darkSwitch"></button></div><div class="tx"><div><b>Notifications</b><div class="muted">Reward and account updates</div></div><button class="switch ${state.settings.notifications?"on":""}" id="notifSwitch"></button></div></div><div class="card" style="margin-top:12px"><button class="btn ghost full" id="privacy">Privacy Policy</button><button class="btn ghost full" style="margin-top:8px" id="terms">Terms of Service</button><button class="btn danger full" style="margin-top:8px" id="logout2">Logout</button></div>`
};
function txList(n){let arr=state.transactions.slice(0,n);return arr.length?arr.map(x=>`<div class="tx"><div><b>${x.type}</b><div class="muted">${x.desc||x.status} · ${x.date}</div></div><div class="${x.points>=0?"plus":"minus"}">${x.points>=0?"+":""}${x.points.toLocaleString()}<br><small>${usd(Math.abs(x.points))}</small></div></div>`).join(""):'<div class="empty">No transactions yet. Your demo activity will appear here.</div>'}
function bind(){
 $$("[data-route]").forEach(b=>b.onclick=()=>setRoute(b.dataset.route));
 $$("[data-task]").forEach(b=>b.onclick=()=>{state.route="taskDetails:"+b.dataset.task;save();render()});
 $$("[data-offer]").forEach(b=>b.onclick=()=>{state.route="offerDetails:"+b.dataset.offer;save();render()});
 $$("[data-taskdetail]").forEach(b=>b.onclick=()=>{state.route="taskDetails:"+b.dataset.taskdetail;save();render()});
 $$("[data-start]").forEach(b=>b.onclick=()=>{let t=state.tasks.find(x=>x.id===b.dataset.start);if(t.status==="Available")t.status="Started";else setRoute("submit:"+t.id);save();render()});
 $$("[data-submit]").forEach(b=>b.onclick=()=>submitTask(b.dataset.submit));
 $("#spinBtn")?.addEventListener("click",doSpin); $("#spinAdBtn")?.addEventListener("click",watchSpinAd);
 $("#watchAd")?.addEventListener("click",watchAd);
 $("#withdrawBtn")?.addEventListener("click",withdraw);
 $("#startOffer")?.addEventListener("click",()=>{let o=state.offers.find(x=>x.id===$("#startOffer").dataset.id);o.status="Started";save();toast("Offer dimulai. Reward menunggu callback provider.");render()});
 $("#readAll")?.addEventListener("click",()=>{state.notifications.forEach(n=>n.unread=false);save();render()});
 $("#language")?.addEventListener("change",e=>{state.user.language=e.target.value;save();render();toast("Language updated")});
 $("#notifSwitch")?.addEventListener("click",()=>{state.settings.notifications=!state.settings.notifications;save();render()});
 $("#privacy")?.addEventListener("click",()=>toast("Privacy Policy: demo prototype. Tambahkan dokumen produksi sebelum rilis."));
 $("#terms")?.addEventListener("click",()=>toast("Terms: demo prototype. Tambahkan terms produksi sebelum rilis."));
 $("#logout2")?.addEventListener("click",logout);
 $("#txFilter")?.addEventListener("change",e=>toast("Filter: "+e.target.value));
}
function submitTask(id){let t=state.tasks.find(x=>x.id===id);t.status="Pending Review";state.pending++;addTx("Task Submission",0,"Pending Review",t.title+" menunggu review");addNotif("Task submitted",t.title+" sedang menunggu review.");save();toast("Bukti dikirim. Status Pending Review.");render()}
function watchSpinAd(){
  if(state.spinAdBusy || state.spinAdReady) return;
  requestUnityRewardedAd("spin");
}
function doSpin(){
 if(!state.spinAdReady){toast("Tonton 1 iklan sampai selesai dulu.");return}
 const r=Math.random()*100;
 let v=0, label="ZONK";
 if(r<60){v=0;label="ZONK"}
 else if(r<85){v=10;label="+10 points"}
 else if(r<97){v=25;label="+25 points"}
 else if(r<99.5){v=50;label="+50 points"}
 else {v=100;label="+100 points"}
 let w=$("#wheel"); if(w) w.style.transform=`rotate(${1440+Math.floor(Math.random()*360)}deg)`;
 setTimeout(()=>{
   state.spinCount=(state.spinCount||0)+1;
   state.spinAdReady=false;
   state.spinAdBusy=false;
   if(v>0){state.points+=v;state.today+=v;state.total+=v;addTx("Lucky Spin",v,"Completed","Reward "+label);addNotif("Lucky Spin reward",`${label} berhasil diterima.`);}
   else {addTx("Lucky Spin",0,"Completed","ZONK — no points");addNotif("Lucky Spin","Hasil spin: ZONK, tidak mendapat poin.");}
   if(state.spinCount===200){
      state.points+=2500; state.today+=2500; state.total+=2500;
      addTx("200 Spin Bonus",2500,"Completed","Bonus $0.50 setelah 200 spin");
      addNotif("200 Spin Bonus","+2,500 points ($0.50) karena mencapai 200 spin.");
   }
   save(); toast(v>0?`Hasil: ${label}`:"Hasil: ZONK 😅"); render();
 },2200);
}
let pendingUnityRewardMode=null;
function requestUnityRewardedAd(mode){
  if(pendingUnityRewardMode) return toast("Tunggu proses iklan yang sedang berjalan.");
  const bridge=window.UnityAdsBridge;
  if(!bridge || typeof bridge.showRewardedAd!=="function")
    return toast("Unity Ads belum terhubung di APK ini. Tidak ada poin yang ditambahkan.");
  pendingUnityRewardMode=mode;
  if(mode==="spin") state.spinAdBusy=true;
  save(); render();
  try { bridge.showRewardedAd(); }
  catch(e){ pendingUnityRewardMode=null; state.spinAdBusy=false; save(); render(); toast("Unity Ads gagal dibuka. Coba lagi nanti."); }
}
// Native Android wrapper must call this only from Unity Ads' completed reward callback.
window.onUnityRewardedAdCompleted=function(completed){
  const mode=pendingUnityRewardMode;
  if(!mode) return;
  pendingUnityRewardMode=null;
  if(mode==="spin") state.spinAdBusy=false;
  if(completed!==true){save();render();toast("Iklan belum selesai. Reward tidak diberikan.");return;}
  if(mode==="spin"){state.spinAdReady=true;save();render();toast("Iklan selesai. Sekarang kamu bisa SPIN.");return;}
  const today=new Date().toISOString().slice(0,10);
  if(state.ads.date!==today) state.ads={count:0,date:today};
  if(state.ads.count>=DAILY_AD_LIMIT){save();render();return toast("Batas rewarded ad hari ini tercapai.");}
  state.ads.count++; state.points+=50; state.today+=50; state.total+=50;
  addTx("Unity Rewarded Ad",50,"Completed","Verified native Unity Ads completion callback");
  addNotif("Rewarded ad reward","+50 points dari iklan Unity yang selesai.");
  save();toast("Reward diterima: +50 points");render();
}
function watchAd(){
 const today=new Date().toISOString().slice(0,10);
 if(state.ads.date!==today) state.ads={count:0,date:today};
 if(state.ads.count>=DAILY_AD_LIMIT) return toast("Batas rewarded ad hari ini tercapai.");
 requestUnityRewardedAd("points");
}
function withdraw(){let a=+$("#withdrawAmount").value||0,m=$("#withdrawMethod").value,d=$("#paymentDetails").value.trim();if(a<MIN_WITHDRAW)return toast("Minimum withdrawal 25,000 points.");if(a>state.points)return toast("Saldo points tidak cukup.");if(!d)return toast("Isi payment details.");state.points-=a;state.pending++;addTx("Withdrawal",-a,"Pending",`${m} · ${usd(a)} · DEMO`);addNotif("Withdrawal submitted",`${a.toLocaleString()} points ke ${m}. Status Pending.`);save();toast("Withdrawal tercatat sebagai Pending (DEMO).");setRoute("transactions")}
async function logout(){try{await window.FirebaseBackend?.signOut(window.FirebaseBackend.auth)}catch(e){} state.loggedIn=false;save();render()}
function applyLang(){let lang=state.user.language||"id";$$("[data-i18n]").forEach(e=>{let k=e.dataset.i18n;if(I18N[lang][k])e.textContent=I18N[lang][k]});$("#notifBadge").textContent=state.notifications.filter(n=>n.unread).length||""}
const oldRoutes=routes;
const proxy=new Proxy(routes,{get(t,p){if(typeof p==="string"&&p.startsWith("taskDetails:"))return ()=>t.taskDetails(p.split(":")[1]);if(typeof p==="string"&&p.startsWith("submit:"))return ()=>t.submit(p.split(":")[1]);if(typeof p==="string"&&p.startsWith("offerDetails:"))return ()=>t.offerDetails(p.split(":")[1]);return t[p]}});
window.routes=proxy;
$("#menuBtn").onclick=()=>$("#drawer").classList.remove("hidden");$("#closeDrawer").onclick=()=>$("#drawer").classList.add("hidden");$("#notifBtn").onclick=()=>setRoute("notifications");$("#logoutBtn").onclick=logout;
$("#drawer").addEventListener("click",e=>{let b=e.target.closest("[data-route]");if(b){$("#drawer").classList.add("hidden");setRoute(b.dataset.route)}});
setTimeout(()=>{ $("#splash").classList.add("hidden"); render(); },900);

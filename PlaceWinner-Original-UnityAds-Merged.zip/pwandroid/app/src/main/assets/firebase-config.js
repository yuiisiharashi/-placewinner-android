
/* Firebase Web SDK integration
   Project: walpaperquest
   NOTE: Firebase web config is not a private server credential.
*/
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  updateProfile,
  sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBlmC24aFN_JqNRatRzGA-FEBJHYDYEAa8",
  authDomain: "walpaperquest.firebaseapp.com",
  projectId: "walpaperquest",
  storageBucket: "walpaperquest.firebasestorage.app",
  messagingSenderId: "373955318735",
  appId: "1:373955318735:web:e7cb0288a78dcb4b7f38ba",
  measurementId: "G-TXR1TDQWVJ"
};

export const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);

window.FirebaseBackend = {
  app: firebaseApp,
  auth,
  db,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  updateProfile,
  sendPasswordResetEmail,
  googleLogin,
  doc,
  getDoc,
  setDoc,
  serverTimestamp
};

async function googleLogin(){
  const provider = new GoogleAuthProvider();
  return await signInWithPopup(auth, provider);
}
async function emailLogin(email, password){
  return await signInWithEmailAndPassword(auth, email, password);
}
async function emailRegister(email, password, displayName){
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  if(displayName) await updateProfile(cred.user, {displayName});
  await ensureUserDocument(cred.user);
  return cred;
}
async function resetPassword(email){
  return await sendPasswordResetEmail(auth, email);
}
async function ensureUserDocument(user) {
  if (!user) return;
  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      uid: user.uid,
      displayName: user.displayName || "",
      email: user.email || "",
      points: 0,
      totalEarningsUsd: 0,
      completedTasks: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  }
}

window.firebaseReady = ensureUserDocument;
window.dispatchEvent(new Event("firebase-backend-ready"));

window.addEventListener("DOMContentLoaded", () => {
  onAuthStateChanged(auth, async (user) => {
    try {
      if (user) {
        await ensureUserDocument(user);
        window.dispatchEvent(new CustomEvent("firebase-auth-ready", {detail: {user}}));
      } else {
        window.dispatchEvent(new CustomEvent("firebase-auth-signed-out"));
      }
    } catch (e) {
      console.error("Firebase user sync error:", e);
    }
  });
});

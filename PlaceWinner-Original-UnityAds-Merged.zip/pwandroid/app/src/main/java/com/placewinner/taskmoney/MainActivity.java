package com.placewinner.taskmoney;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;

public class MainActivity extends Activity {
    // Unity dashboard values supplied by user. Use test mode until integration is verified.
    private static final String GAME_ID = "800394219";
    private static final String REWARDED = "BP_Rewarded_Android";
    private static final String INTERSTITIAL = "BP_Interstitial_Android";
    private static final boolean TEST_MODE = true;
    private WebView webView;
    private boolean rewardedReady = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AdsBridge(), "PlaceWinnerAds");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        UnityAds.initialize(getApplicationContext(), GAME_ID, TEST_MODE, new IUnityAdsInitializationListener() {
            @Override public void onInitializationComplete() { loadRewarded(); }
            @Override public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                runJs("window.onUnityAdError && window.onUnityAdError('Initialization failed');");
            }
        });
    }

    private void loadRewarded() {
        UnityAds.load(REWARDED, new IUnityAdsLoadListener() {
            @Override public void onUnityAdsAdLoaded(String placementId) { rewardedReady = true; }
            @Override public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) { rewardedReady = false; }
        });
    }
    private void runJs(String js) { runOnUiThread(() -> webView.evaluateJavascript(js, null)); }

    public class AdsBridge {
        @JavascriptInterface public void showRewarded() {
            runOnUiThread(() -> {
                if (!rewardedReady) { Toast.makeText(MainActivity.this, "Iklan belum siap, coba lagi sebentar.", Toast.LENGTH_SHORT).show(); loadRewarded(); return; }
                rewardedReady = false;
                UnityAds.show(MainActivity.this, REWARDED, new IUnityAdsShowListener() {
                    @Override public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) { runJs("window.onUnityRewarded && window.onUnityRewarded(false);"); loadRewarded(); }
                    @Override public void onUnityAdsShowStart(String placementId) {}
                    @Override public void onUnityAdsShowClick(String placementId) {}
                    @Override public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
                        boolean completed = state == UnityAds.UnityAdsShowCompletionState.COMPLETED;
                        runJs("window.onUnityRewarded && window.onUnityRewarded(" + completed + ");");
                        loadRewarded();
                    }
                });
            });
        }
        @JavascriptInterface public void showInterstitial() {
            runOnUiThread(() -> UnityAds.load(INTERSTITIAL, new IUnityAdsLoadListener() {
                @Override public void onUnityAdsAdLoaded(String placementId) {
                    UnityAds.show(MainActivity.this, INTERSTITIAL, new IUnityAdsShowListener() {
                        @Override public void onUnityAdsShowFailure(String p, UnityAds.UnityAdsShowError e, String m) {}
                        @Override public void onUnityAdsShowStart(String p) {}
                        @Override public void onUnityAdsShowClick(String p) {}
                        @Override public void onUnityAdsShowComplete(String p, UnityAds.UnityAdsShowCompletionState s) {}
                    });
                }
                @Override public void onUnityAdsFailedToLoad(String p, UnityAds.UnityAdsLoadError e, String m) {}
            }));
        }
    }
}

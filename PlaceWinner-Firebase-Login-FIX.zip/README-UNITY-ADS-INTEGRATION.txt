PlaceWinner Unity Ads Native Integration

Saved Unity IDs recovered from Library project:
- Game ID (Android): 800394219
- Rewarded Ad Unit: BP_Rewarded_Android
- Secondary Interstitial Ad Unit: BP_Interstitial_Android
- TEST_MODE: false (live mode)

This ZIP combines the latest no-demo-reward web assets with an Android WebView wrapper that embeds Unity Ads SDK 4.15.0 and exposes window.UnityAdsBridge.showRewardedAd(). The app awards +50 points only when the native SDK callback returns COMPLETED and invokes window.onUnityRewardedAdCompleted(true). The interstitial unit is exposed as showInterstitialAd() but is not forced automatically.

Build source, not a verified APK. Build using JDK 17 + Android SDK 35 + Gradle 8.9, e.g. `gradle assembleDebug` from pwandroid/. Then install and test on a device. Live ad delivery depends on Unity Dashboard setup, app eligibility, placement configuration, network, consent/privacy setup, and fill. Test on your own device/account and do not click your own production ads.

Important: frontend/localStorage points are still local prototype balances and are not secure cash-redeemable rewards. Production reward balances need trusted server-side validation and anti-fraud protection. Existing login source files are retained from the saved PlaceWinner Android project; test Google login in the resulting APK because WebView popup sign-in can be blocked.

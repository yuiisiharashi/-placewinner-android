CARA BUILD APK PLACEWINNER DARI HP (TANPA LAPTOP)

PENTING:
- Ini adalah SOURCE PROJECT Android, bukan APK siap instal.
- Jangan hapus project lama atau menimpa APK yang sedang dipakai. Tes APK baru terpisah dulu.
- Firebase Android config sekarang disimpan di app/google-services.json dan Google Sign-In native mengirim ID token ke Firebase Web Auth di WebView.
- Pastikan SHA-1 Firebase cocok dengan sertifikat APK yang dibangun; jika OAuth gagal, cek log dan OAuth client ID.
- Proyek ini membuka UI web prototipe lokal dari app/src/main/assets/index.html. Ini BELUM otomatis memakai website online Place Winner milikmu.
- Unity Ads SDK sudah ditambahkan dan bridge showRewardedAd tersedia. Iklan live tetap bergantung pada status Game ID, placement, persetujuan/eligibility dashboard Unity, jaringan, dan ketersediaan iklan.
- Saldo pada UI prototipe masih localStorage/demo, bukan saldo server yang aman untuk penarikan uang.

LANGKAH BUILD DARI HP:
1. Unduh ZIP ini lalu ekstrak.
2. Buat repositori baru di GitHub (misalnya placewinner-android). Set sebagai Private jika ingin.
3. Upload ISI folder proyek ini ke root repositori. Pastikan folder .github/workflows/android-build.yml ada di root repositori, bukan di dalam subfolder tambahan.
4. Buka tab Actions di repositori GitHub, pilih workflow "Build PlaceWinner Android", lalu tekan Run workflow.
5. Tunggu workflow selesai berstatus hijau.
6. Buka run yang selesai, cari bagian Artifacts, lalu unduh PlaceWinner-debug-apk.
7. Ekstrak artifact ZIP dan instal app-debug.apk di HP untuk tes.
8. Tes login, iklan, dan alur poin. Jangan gunakan saldo prototipe untuk menjanjikan penarikan uang.

Jika build gagal, buka workflow yang merah, salin bagian error terakhir atau kirim screenshot ke ChatGPT agar bisa diperbaiki.

Unity Ads:
- Game ID Android: 800394219
- Rewarded Ad Unit: BP_Rewarded_Android
- Interstitial Ad Unit: BP_Interstitial_Android
- Test mode: false

Reward +50 hanya dipanggil setelah SDK melaporkan iklan rewarded selesai (COMPLETED). Jangan klik iklan live milik sendiri untuk mengetes.

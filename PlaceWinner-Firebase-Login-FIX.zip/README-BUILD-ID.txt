PlaceWinner + Unity Ads source merge
Package: com.placewinner.taskmoney
Unity Game ID: 800394219
Rewarded placement: BP_Rewarded_Android
Interstitial placement: BP_Interstitial_Android
Test mode: true

Original PlaceWinner HTML/CSS/JS/Firebase files are placed in app/src/main/assets.
Rewarded points are granted only after the native Unity Ads completed callback.
This is source code, NOT a verified/installable APK. Build in GitHub Actions and test login/ads on a device.
Firebase Google sign-in uses signInWithPopup in the web code; some Android WebViews block popup sign-in, so Google login may still need native OAuth/AppMint integration.
The app currently retains demo/localStorage reward balance; production points must be validated and stored server-side.

# placeWinner-taskmoney

Complete mobile-first HTML/CSS/JavaScript prototype prepared for web-to-APK packaging.

## Included
- Welcome screen with Google-only sign-in UI
- 5-tab navigation: Home, Tasks, Spin, Offerwall, Profile
- Task marketplace, task details and proof submission
- Lucky Spin
- Rewarded Ads demo architecture with 50 points / 10 ads per day
- Offerwall demo with callback-safe reward logic
- Wallet, transactions, withdrawals and payment methods flow
- Notifications
- Profile and settings
- Indonesian/English language selector
- 5,000 points = $1 USD conversion
- LocalStorage persistence
- Demo/test labels where real provider/backend integration is not connected

## Important production integration
This ZIP is a web prototype. Real AdMob Rewarded Video callbacks and server-side Offerwall callbacks require native/backend integration by the APK wrapper/provider. The UI deliberately does not pretend that a click is a real ad completion or payment.

Package target:
com.placewinner.taskmoney


FIREBASE INTEGRATION
- Firebase Web SDK connected to project: walpaperquest
- Authentication provider expected: Google only in the app UI. Firebase Web SDK currently calls signInWithPopup; some Android WebViews block popup sign-in. For reliable APK Google sign-in, configure AppMint native Google Sign-In/OAuth Web Client ID integration if available.
- Firestore user documents are initialized under users/{uid}.
- Production rewards MUST be validated server-side/with Cloud Functions and Firestore Security Rules.
- Rewarded ad and Offerwall rewards are NOT made real by this frontend integration.

LUCKY SPIN TEST UPDATE
- Rewards: ZONK, 10, 25, 50, 100 points.
- 50 and 100 points have intentionally low demo probabilities.
- Each spin requires one completed ad in the test flow.
- 200 completed spins trigger a demo 2,500-point ($0.50) bonus.
- This remains TEST/DEMO; real ad completion must come from a rewarded-ad SDK callback.

FINAL APK BUILD VERSION
- Firebase Authentication: Google + Email/Password.
- Firebase project: walpaperquest.
- Lucky Spin rewards: ZONK, 10, 25, 50, 100 points.
- 50 and 100 points use low-probability outcomes.
- 1 spin requires 1 completed rewarded-ad callback before the spin unlocks.
- Every 200 completed spins grants 2,500 points ($0.50) once per 200-spin milestone.
- This ZIP is still a web-to-APK source. Real rewarded ads require the APK builder/native ad SDK bridge; the demo timer must not be treated as a real ad completion in production.
- Production point/withdrawal rewards should be protected by Firestore Security Rules and a trusted backend/Cloud Functions.


LUCKY SPIN V2
- Bonus $0.50 is explicitly shown as requiring 200 completed spins.
- 1 spin requires 1 completed rewarded ad.
- Rewards: ZONK, 10, 25, 50 (rare), 100 (very rare).
